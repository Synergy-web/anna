$(document).ready(function(){
   $("#textExample").verticaltabs();
    });
});